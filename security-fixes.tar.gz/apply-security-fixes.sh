#!/bin/bash

echo "🔒 開始應用安全修復..."
echo ""

# 檢查是否在專案根目錄
if [ ! -f "package.json" ]; then
    echo "❌ 錯誤：請在 lazypack1210 專案根目錄執行此腳本"
    exit 1
fi

echo "✅ 檢測到專案根目錄"
echo ""

# 備份原始文件
echo "📦 備份原始文件..."
mkdir -p .backups
cp -r services .backups/services-$(date +%Y%m%d-%H%M%S) 2>/dev/null
cp vite.config.ts .backups/vite.config.ts-$(date +%Y%m%d-%H%M%S) 2>/dev/null
echo "✅ 備份完成 (.backups 目錄)"
echo ""

# 提示用戶手動修改 ResultView.tsx
echo "⚠️  注意：ResultView.tsx 需要手動修改"
echo "   請參考 components/ResultView_DOMPurify_Fix.md 文件"
echo "   或手動將所有 sanitizeHtml() 調用替換為 DOMPurify.sanitize()"
echo ""

# 創建前端 .env.local
if [ ! -f ".env.local" ]; then
    echo "VITE_API_URL=http://localhost:3001" > .env.local
    echo "✅ 已創建 .env.local"
else
    echo "⚠️  .env.local 已存在，請手動添加: VITE_API_URL=http://localhost:3001"
fi

# 創建後端 .env
if [ ! -f "backend/.env" ]; then
    echo "⚠️  請創建 backend/.env 並添加您的 GEMINI_API_KEY"
    echo "   範例: cp backend/.env.example backend/.env"
else
    echo "✅ backend/.env 已存在"
fi

echo ""
echo "📦 安裝後端依賴..."
cd backend && npm install && cd ..

echo ""
echo "✅ 安全修復應用完成！"
echo ""
echo "📝 下一步："
echo "  1. 配置 backend/.env (添加您的 GEMINI_API_KEY)"
echo "  2. 修改 components/ResultView.tsx (參考 ResultView_DOMPurify_Fix.md)"
echo "  3. 啟動後端: cd backend && npm start"
echo "  4. 啟動前端: npm run dev"
echo ""
echo "📖 完整說明請查看 SECURITY_FIX_GUIDE.md"
