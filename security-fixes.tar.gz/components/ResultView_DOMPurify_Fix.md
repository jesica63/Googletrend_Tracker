# ResultView.tsx DOMPurify 修復說明

## 需要修改的地方

1. **移除自定義的 sanitizeHtml 函數**（約在第 8-19 行）
2. **將所有 `sanitizeHtml()` 調用替換為 `DOMPurify.sanitize()`**

## 修改範例

### 原來的代碼：
```typescript
const sanitizeHtml = (html: string) => {
  const cleaned = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
  // ... 其他清理邏輯
  return cleaned;
};

// 使用
const cleanHtml = sanitizeHtml(htmlToSanitize);
```

### 修改後：
```typescript
// 直接使用 DOMPurify (已在第 2 行 import)
const cleanHtml = DOMPurify.sanitize(htmlToSanitize, {
  ALLOWED_TAGS: ['p', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'a', 'strong', 'em', 'br', 'img'],
  ALLOWED_ATTR: ['href', 'target', 'src', 'alt', 'class']
});
```

## 具體修改位置

1. **第 79 行附近**: `const cleanHtml = sanitizeHtml(htmlToSanitize);`
   改為: `const cleanHtml = DOMPurify.sanitize(htmlToSanitize, { ALLOWED_TAGS: ['p', 'h1', 'h2', 'h3', 'ul', 'ol', 'li', 'a', 'strong', 'em', 'br'], ALLOWED_ATTR: ['href', 'target'] });`

2. **第 84 行附近**: `return { __html: sanitizeHtml(content) };`
   改為: `return { __html: DOMPurify.sanitize(content) };`

3. **第 95 行附近**: `finalHtml = sanitizeHtml(finalHtml as string);`
   改為: `finalHtml = DOMPurify.sanitize(finalHtml as string);`

4. **第 138 行附近**: `finalHtml = sanitizeHtml(finalHtml as string);`
   改為: `finalHtml = DOMPurify.sanitize(finalHtml as string);`

5. **移除第 8-19 行的 sanitizeHtml 函數定義**
