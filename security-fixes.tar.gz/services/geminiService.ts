import type { AnalysisResult, SitemapUrl } from '../types';

// 後端 API 基礎 URL
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

/**
 * 處理 Sitemap URLs（限制數量）
 */
function processSitemapUrls(urls: SitemapUrl[]): SitemapUrl[] {
  return urls.slice(0, 500);
}

/**
 * 分析文章並生成內部連結建議（透過後端 API）
 */
export async function analyzeArticleWithGemini(
  articleContent: string,
  urlList: SitemapUrl[]
): Promise<AnalysisResult> {
  if (!articleContent || articleContent.trim().length === 0) {
    throw new Error('文章內容不能為空');
  }

  const processedUrls = processSitemapUrls(urlList);

  try {
    const response = await fetch(`${API_BASE_URL}/api/gemini/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        articleContent,
        urlList: processedUrls,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(
        errorData.message || `後端 API 錯誤: ${response.status} ${response.statusText}`
      );
    }

    const result = await response.json();

    if (!result.success || !result.data) {
      throw new Error('後端回應格式錯誤');
    }

    return result.data as AnalysisResult;
  } catch (error) {
    console.error('呼叫 Gemini API 時發生錯誤:', error);
    throw error;
  }
}
