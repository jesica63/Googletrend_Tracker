import type { CurationRequest, CurationStatus, ScrapedContent } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export async function generateCuratedArticle(
  request: CurationRequest,
  onStatusChange: (status: CurationStatus) => void
): Promise<string> {
  const { topic, intro, outline, urls } = request;

  onStatusChange('scraping');
  console.log('[Curation] 開始抓取網頁內容...');

  const maxUrls = 6;
  const urlsToFetch = urls.slice(0, maxUrls);

  let scrapedContents: ScrapedContent[] = [];

  try {
    const response = await fetch(`${API_BASE_URL}/api/scraper/fetch-multiple`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls: urlsToFetch, maxUrls }),
    });

    if (!response.ok) throw new Error('批次抓取失敗');
    const result = await response.json();
    scrapedContents = result.data;
  } catch (error) {
    console.error('抓取失敗:', error);
    throw new Error('所有網址都無法讀取，請確認網址是否公開。');
  }

  if (scrapedContents.length === 0) {
    throw new Error('無法抓取任何有效內容');
  }

  onStatusChange('analyzing');
  console.log('[Curation] 生成文章架構...');

  const defaultOutline = ['背景與前言', '核心議題分析', '主要優勢與挑戰', '未來展望與建議'];
  const finalOutline = outline && outline.length > 0 ? outline : defaultOutline;

  const architectResponse = await fetch(`${API_BASE_URL}/api/gemini/architect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ topic, outline: finalOutline, scrapedContents }),
  });

  if (!architectResponse.ok) throw new Error('架構生成失敗');
  const architectResult = await architectResponse.json();

  const architectDrafts = finalOutline.map((sectionTitle) => ({
    sectionTitle,
    content: '內容',
    sourceIds: [1],
  }));

  onStatusChange('writing');
  console.log('[Curation] 撰寫最終文章...');

  const editorResponse = await fetch(`${API_BASE_URL}/api/gemini/editor`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ topic, intro, architectDrafts, scrapedContents }),
  });

  if (!editorResponse.ok) throw new Error('文章生成失敗');
  const editorResult = await editorResponse.json();

  onStatusChange('done');
  return editorResult.data;
}
